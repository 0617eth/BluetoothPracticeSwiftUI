//
//  BluetoothPracticeSwiftUIGithubApp.swift
//  BluetoothPracticeSwiftUIGithub
//

import SwiftUI

@main
struct BluetoothPracticeSwiftUIGithubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
